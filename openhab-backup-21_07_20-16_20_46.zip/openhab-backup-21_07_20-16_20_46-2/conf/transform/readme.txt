Transformations like map or jsonpath can utilize configuration files with data definitions.
These files have their specific file extensions and syntax definition.

Check out the openHAB documentation for more details:
https://www.openhab.org/docs/configuration/transformations.html
